<?php
/*		PRODUCTION		*/ 
	mb_internal_encoding("UTF-8");
	mb_http_output('UTF-8');
	$phone=$_REQUEST["phone"];
	$smscenter=$_REQUEST["smscenter"];
	$text=rawurldecode($_REQUEST["text"]);
	$headers=getallheaders();
	
	if(empty($phone)){
	 $phone=$headers['phone'];
	}
	if(empty($smscenter)){
	 $phone=$headers['smscenter'];
	}
	$dan=null;
	$mesec=null;
	$godina=null;
	$vreme=null;
	
	if(strtolower($text)=="info" || empty($text) || strlen($text) == 0 || $text == "")
	{
		info(); 
	}
	else
	{
		$text=trim($text);
		$tabela="rezervacije";
		$parts = explode (" ", $text);
		$dmy_array=dmy_setting_values_from_text($parts);
		$conn=connect();
		
		if(isset($dmy_array['dan']))
		{
			$dan=$dmy_array['dan'];
		}
		if(isset($dmy_array['mesec']))
		{
			$mesec=$dmy_array['mesec'];
		}
		if(isset($dmy_array['godina']))
		{
			$godina=$dmy_array['godina'];
		}
		if(isset($dmy_array['vreme']))
		{
			$vreme=$dmy_array['vreme'];
		}
		
		if(strtolower($parts[0])=="ter") //parts[0] moze biti ili REZ ILI TER
		{
$send="";
header("Content-Type: text/html; charset=utf-8");
			if($dan==null)
			{	
				$dan_i_7 = date("d")+7;
				
				$query="SELECT * FROM $tabela WHERE (datum_rezervacije BETWEEN '".date("Y-m-d")."' AND '".date("Y-m-".$dan_i_7)."') AND slobodan=1 order by datum_rezervacije, vreme";
				$rez=mysqli_query($conn,$query);
				
				if(isset($rez) || $rez!=null || !empty($rez))
				{
					$send.="Slobodni termini sledecih nedelju dana. "; //OVDE ISPISATI SVE ZA TAJ DAN ILI NEDELJU VIDECEMO
					while($r=mysqli_fetch_array($rez))
					{
						$send.="Termin ".$r['datum_rezervacije']." od ".$r['vreme']." je slobodan.";
					}
					$send.="Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME";
				
				}
				else
				{
					$send.="Za izabrani datum nazalost nemamo slobodnih termina, molimo pokusajte ponovo. Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME";
				}
				header("text: ".$send);
				disconnect($conn);
			}
			else
			{
				if($mesec==null)
				{					
					$dan_i_1=$dan+1;
					
					$query="SELECT * FROM $tabela WHERE (datum_rezervacije >= '".date("Y-m-".$dan)."' AND datum_rezervacije <'".date("Y-m-".$dan_i_1)."') AND slobodan=1 order by vreme";
					$rez=mysqli_query($conn,$query);
					$var_dump = var_dump($rez);
					if(isset($rez))
					{
						$send.="Slobodni termini ".$dan."-og:"; //ZA TAJ ODREDJENI DAN (ovde nije prolsedio mesec)
						while($r=mysqli_fetch_array($rez))
						{
							$send.= "Termin ".$r['datum_rezervacije']." od ".$r['vreme']." je slobodan";
						}
						$send.=" Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME ";
					}
					else
					{
						$send.="Za izabrani datum nazalost nemamo slobodnih termina, molimo pokusajte ponovo. Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME";
					}
					
					header("text: ".$send);
					disconnect($conn);
				}
				else
				{
					if($godina==null)
					{
						$dan_i_1=$dan+1;
						
						$query="SELECT * FROM $tabela WHERE ( datum_rezervacije >= '".date("Y-".$mesec."-".$dan)."' AND datum_rezervacije <'".date("Y-".$mesec."-".$dan_i_1)."') AND slobodan=1 order by vreme";
						
						$rez=mysqli_query($conn,$query);
						if(isset($rez))
						{
							$send.= "Slobodni termini ".$dan."-".$mesec.":"; //ZA TAJ ODREDJENI DAN i MESEC (ovde nije prolsedio GODINA)
					
							while($r=mysqli_fetch_array($rez))
							{
								$send.=" Termin ".$r['datum_rezervacije']." od ".$r['vreme']." je slobodan";
							}
							$send.=" Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME";
						}
						else
						{
							$send.="Za izabrani datum nazalost nemamo slobodnih termina, molimo pokusajte ponovo. Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME";
						}
						header("text: ".$send);
						disconnect($conn);
					}
					else
					{
						$dan_i_1=$dan+1;
						$query="SELECT * FROM $tabela WHERE ( datum_rezervacije >= '".date($godina."-".$mesec."-".$dan)."' AND datum_rezervacije <'".date($godina."-".$mesec."-".$dan_i_1)."') AND slobodan=1 order by vreme";
						
						$rez=mysqli_query($conn,$query);
						if(isset($rez) || $rez!=null || !empty($rez))
						{
							$send.=" Slobodni termini ".$dan."-".$mesec."-".$godina." :"; //OVDE ISPISATI SVE ZA TAJ ODREDJENI DATUM
							while($r=mysqli_fetch_array($rez))
							{
								$send.=" Termin ".$r['datum_rezervacije']." od ".$r['vreme']." je slobodan!";
							}
							$send.=" Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME";						
						}
						else
						{
							$send.="Za izabrani datum nazalost nemamo slobodnih termina, molimo pokusajte ponovo. Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME";
						}
						header("text: ".$send);
						disconnect($conn);
					}
				}
			}
		}
		elseif(strtolower($parts[0])=="rez")
		{
			if($dan!=null && $godina!=null && $mesec!=null && $vreme!=null)
			{
				$dan_i_1=$dan+1;
				$rest = substr($phone, -3);
				$rand=rand(0,999999);
				$kod = $rest.$rand;
			
			$kod =intval($kod);
	
				$query=sprintf("SELECT * FROM $tabela WHERE ( datum_rezervacije >= '".date($godina."-".$mesec."-".$dan)."' AND datum_rezervacije <'".date($godina."-".$mesec."-".$dan_i_1)."') AND vreme=%d",$vreme);
				$rez=mysqli_query($conn, $query);
				
				$r=mysqli_fetch_assoc($rez);

				if($r['slobodan']==1)
				{
					$query=sprintf("UPDATE rezervacije SET broj_telefona=$phone, vreme=%d, 
					datum_rezervacije='".date($godina."-".$mesec."-".$dan)."', slobodan=0,kod=%d WHERE id_rezervacije=%d",
					$vreme,$kod,$r['id_rezervacije']);
					
					if(mysqli_query($conn, $query))
					{
						header("text: Uspesno ste rezervisali Vas termin!! Ukoliko zelite da uklonite rezervaciju posaljite IZB KOD koji budete dobili na kraju ove poruke".$kod);
					}
					else
					{
						header("text: Trenutno imamo problema sa Vasom rezervacijom, pokusajte ponovo uskoro! Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME");
					}	
				}
				else
				{
					header("text: Termin koji ste izabrali nije slobodan pokusajte ponovo! Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME");
				}				
				disconnect($conn);
			}
			else
			{
				header("text: Podaci za rezervaciju nisu prosledjeni u pravilnom formatu, molimo Vas pokusajte ponovo! Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME");
			}
		}
		elseif(strtolower($parts[0])=="izb")
		{
			$kod=0;
			if(isset($parts[1]) && $parts[1]!=null)
			{
				$kod = intval($parts[1]);
				
				if (!preg_match('/^\d{7,10}$/', $kod) || $kod==0) {
					$kod=null;
					header("text: Kod koji ste ukucali nije u skladu sa pravilima, molimo Vas pokusajte ponovo!");
				}
				
				if($kod!=null){
					
					$query=sprintf("UPDATE rezervacije SET broj_telefona=null, slobodan=1, kod=null WHERE kod=%d",$kod);
					if(mysqli_query($conn, $query)){
						header("text: Uspesno ste izbrisali rezervaciju. Ukoliko zelite da rezervisete termin posaljite REZ DAN MESEC GODINA VREME");
						disconnect($conn);
					} else {
						
						header("text: Kod koji ste ukucali nije u skladu sa pravilima, molimo Vas pokusajte ponovo!");
					}
				}
			}
			else
			{
				echo info();
			}
		}
		else
		{
			echo info();
		}
	}
	
	function info()
	{
		header("text: Da bi ste pogledali sve slobodne termine posaljite TER. Da bi ste pogledali sve slobodne termine odredjenog dana u mesecu posaljite TER DAN MESEC GODINA.");
	}
	
	function dmy_setting_values_from_text($parts)
	{
		$dmy_array=[];
		
		if(isset($parts[1]) && $parts[1]!=null)
		{
			$dan = intval($parts[1]);
			
			if($dan==0)
			{
				$dan=null;
			}
			if($dan<1 || $dan >31)
			{
				$dan=null;
			}
		}
		if(isset($parts[2]) && $parts[2]!=null)
		{
			$mesec = intval($parts[2]);
			
			if($mesec==0)
			{
				$mesec=null;
			}
			if($mesec<1 || $mesec >12)
			{
				$mesec=null;
			}
		}
		
		if(isset($parts[3]) && $parts[3]!=null)
		{
			$godina = intval($parts[3]);
			
			if($godina==0)
			{
				$godina=null;
			}
			if($godina<2017 || $godina >2020)
			{
				$godina=null;
			}
		}
		
		if(isset($parts[4]) && $parts[4]!=null)
		{
			$vreme = intval($parts[4]);
			
			if($vreme==0)
			{
				$vreme=null;
			}
			if($vreme<7 || $vreme>24)
			{
				$vreme=null;
			}
		}
		
		if(isset($dan))
		{
			$dmy_array['dan']=$dan;
		}
		if(isset($mesec))
		{
			$dmy_array['mesec']=$mesec;
		}
		if(isset($godina))
		{
			$dmy_array['godina']=$godina;
		}
		if(isset($vreme))
		{
			$dmy_array['vreme']=$vreme;
		}
		
		return $dmy_array; 
	}
	
	function connect(){
		 $db_serverName="localhost";
		 $db_username="id1669126_jurguk";
		 $db_password="aleksa007";
		 $db_database="id1669126_milvol_sms";
		 $conn=mysqli_connect($db_serverName,$db_username,$db_password);
		 $baza=mysqli_select_db($conn,$db_database);
		 mysqli_set_charset($conn,'utf8');
		 
		 return $conn;
		}
		
	function disconnect($conn){
		mysqli_close($conn);
	}	
?>