<form action="amici.php" method="GET">
	<input type="textbox" id="tbText" name="tbText" /><br/><br/>
	<input type="textbox" id="tbText" name="tbTelefon" />
	<input type="submit" name="btnSend"/>
		
</form>